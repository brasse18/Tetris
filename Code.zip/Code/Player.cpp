#include "Class.h"

Class::Class(){}
