#include <iostream> // inport input stream

using namespace std;

int main ()  // funktions start
 {
		
	return 0;
 }
