//
// Created by brasse on 12/12/16.
//

#ifndef TETRIS_BLOCKST_H
#define TETRIS_BLOCKST_H

#include "Blocks.h"
#include "Box.h"
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

class BlocksT : public Blocks {
public:
    BlocksT();
};


#endif //TETRIS_BLOCKST_H
