#ifndef PLAYER_H
#include <string>

using namespace std;

class Player
{
	private:
	public:
		Player();
};
#endif
