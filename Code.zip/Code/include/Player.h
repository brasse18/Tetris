#ifndef CLASS_H
#include <string>

using namespace std;

class Class
{
	private:
	public:
		Class();
};
#endif
