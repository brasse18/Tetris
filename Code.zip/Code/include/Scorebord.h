#ifndef SCOREBORD_H
#include <string>

using namespace std;

class Scorebord
{
	private:
	public:
		Scorebord();
};
#endif
