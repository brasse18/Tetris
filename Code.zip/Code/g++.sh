g++ main.cpp Game.cpp Box.cpp -o tetris -lsfml-system -lsfml-window -lsfml-graphics
