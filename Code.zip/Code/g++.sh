g++ main.cpp Game.cpp Box.cpp Blocks.cpp Playfild.cpp Menu.cpp -o tetris -lsfml-system -lsfml-window -lsfml-graphics
