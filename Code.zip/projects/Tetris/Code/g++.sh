g++ main.cpp Game.cpp Box.cpp Blocks.cpp Playfild.cpp Menu.cpp BlocksL.cpp -o tetris -lsfml-system -lsfml-window -lsfml-graphics
