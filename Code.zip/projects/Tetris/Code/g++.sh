g++ main.cpp -o tetris -lsfml-system -lsfml-window -lsfml-graphics
