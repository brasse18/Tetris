//
// Created by brasse on 12/12/16.
//

#ifndef TETRIS_BLOCKSI_H
#define TETRIS_BLOCKSI_H

#include "Blocks.h"
#include "Box.h"
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

class BlocksI : public Blocks {
public:
    BlocksI();
};


#endif //TETRIS_BLOCKSI_H
